from flask import Flask, request, render_template
import librosa
import numpy as np
from tensorflow.keras.models import load_model

# Define constants
duration = 30  # duration of audio clip in seconds
sr = 22050  # sampling rate
n_mfcc = 13  # number of MFCCs to extract
n_fft = 2048  # length of the FFT window
hop_length = 512 # hop length between frames
genre_names = ['blues', 'classical', 'country', 'disco', 'hiphop', 'jazz', 'metal', 'pop', 'reggae', 'rock']

# Load saved model
model = load_model('music_genre_cnn.h5')

# Initialize Flask app
app = Flask(__name__)

# Define function for processing audio data
def process_audio(file_path):
    signal, sr_local = librosa.load(file_path, duration=duration, sr=sr)
    mfccs = librosa.feature.mfcc(signal, sr=sr_local, n_mfcc=n_mfcc, n_fft=n_fft, hop_length=hop_length)
    # Pad mfccs array with zeros to make it a fixed shape
    mfccs = np.pad(mfccs, ((0, 0), (0, 1292 - mfccs.shape[1])), mode='constant')
    return mfccs

# Define function for predicting the genre of an audio file
def predict_genre(file_path, model):
    mfccs = process_audio(file_path)
    mfccs = np.array(mfccs)
    mfccs = mfccs.reshape((1, n_mfcc, 1292, 1))
    predicted_probabilities = model.predict(mfccs)
    predicted_genre_index = np.argmax(predicted_probabilities)
    predicted_genre_name = genre_names[predicted_genre_index]
    return predicted_genre_name

# Define home route
@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        if 'file' not in request.files:
            message = 'No file part'
            return render_template('index.html', message=message)
        file = request.files['file']
        if file.filename == '':
            message = 'No selected file'
            return render_template('index.html', message=message)
        if file:
            message = 'Predicting the Music. Please wait...'
            file_path = 'audio.wav'
            file.save(file_path)
            predicted_genre_name = predict_genre(file_path, model)
            return render_template('index.html', prediction=predicted_genre_name)
    return render_template('index.html')

# Run Flask app
if __name__ == '__main__':
    app.run(debug=True)
