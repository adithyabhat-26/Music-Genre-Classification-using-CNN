import os
import librosa
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras import layers, models

# Define constants
duration = 30  # duration of audio clip in seconds
sr = 22050  # sampling rate
n_mfcc = 13  # number of MFCCs to extract
n_fft = 2048  # length of the FFT window
hop_length = 512 # hop length between frames

# Define function for processing audio data
def process_audio(file_path):
    signal, sr_local = librosa.load(file_path, duration=duration, sr=sr)
    mfccs = librosa.feature.mfcc(signal, sr=sr_local, n_mfcc=n_mfcc, n_fft=n_fft, hop_length=hop_length)
    # Pad mfccs array with zeros to make it a fixed shape
    mfccs = np.pad(mfccs, ((0, 0), (0, 1292 - mfccs.shape[1])), mode='constant')
    return mfccs

# Define function for loading audio data and labels
def load_data(data_dir):
    X = []
    y = []
    for label_dir in os.listdir(data_dir):
        for file_name in os.listdir(os.path.join(data_dir, label_dir)):
            file_path = os.path.join(data_dir, label_dir, file_name)
            mfccs = process_audio(file_path)
            X.append(mfccs)
            y.append(label_dir)
    return X, y

# Load data and labels
train_data_dir = 'Training'
test_data_dir = 'Testing'

X_train, y_train = load_data(train_data_dir)
X_test, y_test = load_data(test_data_dir)

# Convert labels to integers
label_to_int = {label: i for i, label in enumerate(sorted(set(y_train)))}
y_train = [label_to_int[label] for label in y_train]
y_test = [label_to_int[label] for label in y_test]

# Convert data and labels to NumPy arrays
X_train = np.array(X_train)
X_test = np.array(X_test)
y_train = np.array(y_train)
y_test = np.array(y_test)

# Reshape data to match the expected input shape of the model
X_train = X_train.reshape((-1, n_mfcc, 1292, 1))
X_test = X_test.reshape((-1, n_mfcc, 1292, 1))

# Build model
model = models.Sequential([
    layers.Reshape((13, 1292, 1), input_shape=(n_mfcc, 1292, 1)),
    layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((1, 2)), 
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(len(label_to_int), activation='softmax')
])

# Compile model
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Train model
model.fit(X_train, y_train, epochs=10, validation_data=(X_test, y_test))

# Save model
model.save('music_genre_cnn.h5')
