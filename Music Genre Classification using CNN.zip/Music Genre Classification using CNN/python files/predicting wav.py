import librosa
import numpy as np
from tensorflow.keras.models import load_model

# Define constants
duration = 30  # duration of audio clip in seconds
sr = 22050  # sampling rate
n_mfcc = 13  # number of MFCCs to extract
n_fft = 2048  # length of the FFT window
hop_length = 512 # hop length between frames

# Load saved model
model = load_model('music_genre_cnn.h5')

# Define function for processing audio data
def process_audio(file_path):
    signal, sr_local = librosa.load(file_path, duration=duration, sr=sr)
    mfccs = librosa.feature.mfcc(signal, sr=sr_local, n_mfcc=n_mfcc, n_fft=n_fft, hop_length=hop_length)
    # Pad mfccs array with zeros to make it a fixed shape
    mfccs = np.pad(mfccs, ((0, 0), (0, 1292 - mfccs.shape[1])), mode='constant')
    return mfccs

# Define function for predicting the genre of an audio file
def predict_genre(file_path, model):
    mfccs = process_audio(file_path)
    mfccs = np.array(mfccs)
    mfccs = mfccs.reshape((1, n_mfcc, 1292, 1))
    predicted_probabilities = model.predict(mfccs)
    predicted_genre_index = np.argmax(predicted_probabilities)
    return predicted_genre_index

# Predict genre of an audio file
file_path = r'C:\Users\Dell\Downloads\exp.wav'
predicted_genre_index = predict_genre(file_path, model)
genre_names = ['blues', 'classical', 'country', 'disco', 'hiphop', 'jazz', 'metal', 'pop', 'reggae', 'rock']
predicted_genre_name = genre_names[predicted_genre_index]
print('\n \n  Predicted genre name: ', predicted_genre_name)

